console.log("hi");

let clickedMovieIndex;

let MOVIE_NAME = 0; // place in array
let MOVIE_LINK = 4; // place in array
let POSTER_NAME = 1;

///@  call the functions  @///
showMoviesPosters();


/// # create functions # /// 
function showMoviesPosters(){
    let fullMovieTag = ''; 
    let imageFolder = '../../data/movies_posters/';
    for(let i = 0; i < moviesData.length; i++) {
        fullMovieTag = `<img src="${imageFolder}${moviesData[i][POSTER_NAME]}" title="${moviesData[i][MOVIE_NAME]}" alt="${moviesData[i][MOVIE_NAME]}">`;
        $("#div_movie_database").append(fullMovieTag);
    }

}
///$  jQuery  $///
$("#div_movie_database img").click(function(){
    clickedMovieIndex = $("#div_movie_database img").index(this);

    console.log("clicked!" + clickedMovieIndex + moviesData[MOVIE_LINK]);
    window.open(moviesData[clickedMovieIndex][MOVIE_LINK]);
});
