let moviesData = [          
   ['Rocky III', 'poster.png', '1982', 'other', 'https://www.imdb.com/title/tt0084602'],
   ['October Sky', 'poster.png', '1999', 'true_story', 'https://www.imdb.com/title/tt0132477']
];  




